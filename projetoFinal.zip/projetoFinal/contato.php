<?php include_once 'header1.php'

?>
<!DOCTYPE html>
<html>
	<head>
    <title>Contato</title>
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
        <link rel="stylesheet" href="css1/style.css">
        
      
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	

    

	<style>
         .contact {
          border-radius: 5px;
          background-color: #f2f2f2;
          padding: 10px;
        }

	</style>
	</head>
        <div class="container">
           <div class="contact">
              <div class="row">
                  <div class="col-8">
                        <h3>Fale Conosco</h3>
                <div class="form-group">
                  <label for="usr">Nome:</label>
                  <input type="text" class="form-control" id="nome" >
                </div>
                <div class="form-group">
                  <label for="email">E-mail:</label>
                  <input type="text" class="form-control" id="email">
                </div>
                <div class="form-group">
                  <label for="comment">Mensagem:</label>
                  <textarea class="form-control" rows="5" id="mensagem" name="text"></textarea>
                </div>
                      </div><!--fim div col-8-->
                      <div class="col-4">
                     <h3>Informações</h3>
                    <ul class="social ">
                        <li><span>Endereço </span></li>
                        <li><span>Telefone</span></li>
                        <li><a href="jessica.caroline.ti@gmail.com">email</a></li>
                    </ul>
                            
                    <div class="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14709.975910934552!2d-43.35040832578072!3d-22.821206782823296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9964bb211494e3%3A0x14c34af46a483762!2sAcari%2C%20Rio%20de%20Janeiro%20-%20RJ!5e0!3m2!1spt-BR!2sbr!4v1601321660579!5m2!1spt-BR!2sbr" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div><!--fim div mapa-->
                    <p></p>
     
                      </div><!--fim div col-4-->
                      </div><!--fim div row-->
            <div class="clearfix"> </div>
        </div><!--fim div contact-->
        <p></p>
        </div><!--fim div container-->
        </html/>
