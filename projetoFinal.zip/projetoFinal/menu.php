<?php include_once 'header1.php'

?>
<style>
    .contact {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}

</style>

<div class="container">
   <div class="contact">
        <div class="row">
              <div class="col-10"><h1>Bem-vindo !!!</h1></div>
              <div class="col-2">
                  <p> Bem vindo : admin</p> </div>
          </div>
          
            <ul class="nav">
              <li class="nav-item">
                <a class="nav-link active" href="usuario/ConsultarUsuario.php">Cadastro de Usuários</a>
              </li>
                <a class="nav-link active" href="blog/ConsultarBlog.php">Cadastros do Blog</a>
              </li>
            </ul>
    
        <hr>
        <br>   
  
 
 
</div>
</div>
 