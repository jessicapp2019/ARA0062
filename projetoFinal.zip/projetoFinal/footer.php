<!DOCTYPE html>
<html>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="css1/style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


<body> 
	<div class="container">

        <div class="footer">
            <p class="footer-class">© 2020 Todos os direitos reservados | Template by  </p>
            <a href="#home" class="scroll to-Top" >  Ir para o topo !</a>
        <div class="clearfix"> </div>
        </div><!--fim div foter-->

	</div><!--fim div container-->
  
</body>
</html>