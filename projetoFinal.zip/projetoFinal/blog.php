<?php include_once 'header1.php'

?>
<!DOCTYPE html>
<html>
	<head>
    <title>Blog</title>
 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
       
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" href="css1/style.css">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<style>
         .contact {
          border-radius: 5px;
          background-color: #f2f2f2;
          padding: 10px;
        }

	</style>
	</head>
        <div class="container">
           <div class="contact">
             <div class="row row-cols-1 row-cols-md-3">
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/cao.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Bolinha</h5>
        <p class="card-text">Porto Alegre / Rio Grande do Sul</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/gato.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Barry</h5>
        <p class="card-text">São Paulo / SP</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/cao2.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Cockie</h5>
        <p class="card-text">Rio de Janeiro / RJ</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/cao3.jpeg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Gohan</h5>
        <p class="card-text">Rio de Janeiro / RJ</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/gato2.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Princesa</h5>
        <p class="card-text">Araraquara / SP</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/cao7.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Jade</h5>
        <p class="card-text">Juiz de Fora / MG</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/gato3.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Dina</h5>
        <p class="card-text">Salvador / BA</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/cao5.jpeg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Lock</h5>
        <p class="card-text">Curitiba / PR</p>
      </div>
    </div>
  </div>
  <div class="col mb-4">
    <div class="card">
      <img src="imagens/gato4.jpg" class="card-img-top" alt="..." height="190px">
      <div class="card-body">
        <h5 class="card-title">Luz</h5>
        <p class="card-text">Rio de Janeiro / RJ</p>
      </div>
    </div>
  </div>
</div><!--fim div rom-->
                </div>
            <div class="clearfix"> </div>
        </div>
        <p></p>
        </div>
        </html/>
